# Launcher Ligero

Launcher para Android sin anuncios y con el mínimo consumo: reloj, calendario semanal con tus próximos eventos y las apps que tú elijas en la pantalla de inicio.

## Qué incluye

Diseño de panel claro: fondo gris azulado, tarjetas blancas, acento azul, botones en píldora e iconos cuadrados uniformes.

- Saludo según la hora («Buenos días», «Buenas tardes», «Buenas noches»), fecha y botón de Ajustes.
- Tarjeta azul destacada con la hora, el resumen del día y el progreso del día (tócala para abrir las alarmas).
- Batería a todo el ancho con barra de progreso.
- Agenda: semana L–D con hoy en azul y un punto en los días con eventos, más los 3 próximos eventos con su fecha y horario.
- «Categorías»: pestañas Redes, IA, Personal, Gym, Deportes y Otros, cada una con su rejilla de 4 columnas (máx. 12 apps). Se recuerda la última pestaña abierta. Mantén pulsada una app para quitarla, moverla a otra categoría o ver su información.
- Dock fijo abajo: Teléfono, WhatsApp, Brave y Cámara. Mantén pulsado un icono del dock para cambiarlo por otra app o restablecerlo.
- «Todas»: lista alfabética de todo lo instalado. «Editar»: elige qué apps van en la categoría abierta.

## Por qué consume poco

- Cero dependencias: nada de AndroidX, Compose ni SDKs de terceros.
- Sin permiso de INTERNET: no puede mostrar anuncios ni enviar datos.
- Sin servicios, alarmas ni temporizadores en segundo plano. Solo escucha instalaciones y desinstalaciones de apps, y solo mientras el launcher está vivo.
- Al volver a inicio no se reconstruye nada que no haya cambiado: apps y dock se redibujan solo si cambia su configuración o se instala/desinstala algo.
- Los iconos se piden al sistema una sola vez y se guardan ya recortados en una caché con tope de 3 MB.
- El calendario se consulta como mucho cada 30 s (o al cambiar de día), no en cada vuelta a inicio.
- La batería se lee al volver a inicio, sin escuchar cambios en segundo plano.
- Solo se cargan los iconos de la categoría abierta; la lista completa de apps son solo nombres.
- Libera iconos y nombres cacheados cuando el sistema pide memoria.
- Sin fondo de pantalla detrás (fondo liso): menos trabajo para la GPU.
- R8 activado en release (`isMinifyEnabled` + `isShrinkResources`).

## Comprobar el consumo en tu móvil

- Memoria: `adb shell dumpsys meminfo com.ligero.launcher` (mira «TOTAL PSS»).
- Batería: Ajustes → Batería → Uso de batería; debería aparecer con un consumo mínimo o no aparecer.
- CPU y memoria en directo: Android Studio → View → Tool Windows → Profiler, con el launcher abierto.

## Compilar e instalar

1. Abre la carpeta `LauncherLigero` en Android Studio (Ladybug o posterior). La primera sincronización descarga Gradle y el plugin de Android.
2. Conecta el móvil con depuración USB y pulsa Run, o compila con `./gradlew assembleRelease` (el APK queda en `app/build/outputs/apk/release/`).
3. Pulsa el botón de inicio y elige «Launcher Ligero» como predeterminado (o en Ajustes → Apps → Apps predeterminadas → App de inicio).
4. Toca la tarjeta del calendario para conceder el permiso de lectura.

Requisitos: Android 8.0 (API 26) o superior.

Nota: el build release se firma con la clave debug para que puedas instalarlo directamente. Si algún día lo publicas, crea tu propia clave de firma.
