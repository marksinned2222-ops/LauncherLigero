plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ligero.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ligero.launcher"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // Clave de firma fija: así cada nueva versión se instala encima de la anterior
    signingConfigs {
        create("ligero") {
            storeFile = file("ligero.jks")
            storePassword = "QvHm9whncnsPMg2dhbCN"
            keyAlias = "ligero"
            keyPassword = "QvHm9whncnsPMg2dhbCN"
        }
    }

    buildTypes {
        release {
            // Reduce tamaño y memoria: elimina código y recursos sin usar
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
            signingConfig = signingConfigs.getByName("ligero")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Sin dependencias: ni AndroidX, ni Compose, ni SDKs de anuncios o analítica.
