package com.ligero.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentCallbacks2
import android.content.ComponentName
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

/**
 * Launcher ligero estilo panel claro: saludo, tarjeta azul con la hora,
 * indicadores, agenda, apps favoritas y un dock fijo.
 * Sin dependencias, sin servicios en segundo plano y sin permiso de internet.
 */
class MainActivity : Activity() {

    private data class AppEntry(val label: String, val component: ComponentName)
    /** loadIcon solo se ejecuta si el icono no está en caché */
    private class DockTarget(val intent: Intent?, val loadIcon: (() -> Drawable?)?, val label: String)
    private class StatTile(val value: TextView, val pill: TextView, val fill: View)

    private val prefs by lazy { getSharedPreferences("ligero", MODE_PRIVATE) }

    /** Caché de iconos con tope de memoria: si se llena, descarta los menos usados. */
    private val iconCache = object : LruCache<String, BitmapDrawable>(ICON_CACHE_BYTES) {
        override fun sizeOf(key: String, value: BitmapDrawable) = value.bitmap.byteCount
    }
    private val labelCache = HashMap<String, String>()

    // Firmas de lo último dibujado: si no cambian, no se reconstruyen las vistas
    private var appsSig: String? = null
    private var dockSig: String? = null
    private var lastCalendarQuery = 0L
    private var lastCalendarDay: LocalDate? = null

    /** Solo existe mientras el launcher vive; se activa únicamente cuando se instala, actualiza o desinstala una app. */
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            iconCache.evictAll()
            labelCache.clear()
            appsSig = null
            dockSig = null
            // Si el inicio está a la vista, se actualiza ya; si no, al volver
            if (hasWindowFocus()) {
                renderFavorites()
                renderDock()
            }
        }
    }

    private lateinit var greeting: TextView
    private lateinit var dateText: TextView
    private lateinit var heroInfo: TextView
    private lateinit var daySegments: LinearLayout
    private lateinit var dayPct: TextView
    private lateinit var battery: StatTile
    private lateinit var weekStrip: LinearLayout
    private lateinit var eventsBox: LinearLayout
    private lateinit var categoryTabs: LinearLayout
    private lateinit var appsBox: LinearLayout

    /** Categoría seleccionada (índice en CATEGORIES), recordada entre sesiones */
    private var selectedCat: Int
        get() = prefs.getInt(KEY_SEL_CAT, 0).coerceIn(0, CATEGORIES.lastIndex)
        set(v) { prefs.edit().putInt(KEY_SEL_CAT, v).apply() }
    private lateinit var dock: LinearLayout

    private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Iconos oscuros en las barras del sistema, sobre el fondo claro
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        greeting = findViewById(R.id.greeting)
        dateText = findViewById(R.id.date)
        heroInfo = findViewById(R.id.heroInfo)
        daySegments = findViewById(R.id.daySegments)
        dayPct = findViewById(R.id.dayPct)
        weekStrip = findViewById(R.id.weekStrip)
        eventsBox = findViewById(R.id.events)
        categoryTabs = findViewById(R.id.categoryTabs)
        appsBox = findViewById(R.id.apps)
        dock = findViewById(R.id.dock)
        migrateOldFavorites()

        // Estilos: tarjetas blancas, tarjeta destacada azul y botones en píldora
        findViewById<View>(R.id.heroCard).background = rounded(BLUE, 20)
        listOf(R.id.calendarCard, R.id.appsCard).forEach { findViewById<View>(it).background = rounded(Color.WHITE, 16) }
        dock.background = rounded(Color.WHITE, 20)
        findViewById<View>(R.id.btnSettings).background = rounded(Color.WHITE, 999)
        findViewById<View>(R.id.heroTag).background = rounded(Color.WHITE, 999)
        listOf(R.id.btnCalendar, R.id.btnAll).forEach { findViewById<View>(it).background = outlinePill() }
        findViewById<View>(R.id.btnEdit).background = rounded(BLUE, 999)

        battery = buildBatteryTile(findViewById(R.id.tileBattery))
        renderCategories()

        findViewById<View>(R.id.btnSettings).setOnClickListener { launch(Intent(Settings.ACTION_SETTINGS)) }
        findViewById<View>(R.id.heroCard).setOnClickListener { launch(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }
        findViewById<View>(R.id.tileBattery).setOnClickListener { launch(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) }
        findViewById<View>(R.id.btnCalendar).setOnClickListener { onCalendarTap() }
        findViewById<View>(R.id.calendarCard).setOnClickListener { onCalendarTap() }
        findViewById<View>(R.id.btnAll).setOnClickListener { showAllApps() }
        findViewById<View>(R.id.btnEdit).setOnClickListener { pickFavorites() }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(packageReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(packageReceiver, filter)
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        val locale = Locale.getDefault()
        val hour = LocalTime.now().hour
        greeting.text = when (hour) {
            in 6..12 -> "Buenos días"
            in 13..20 -> "Buenas tardes"
            else -> "Buenas noches"
        }
        dateText.text = LocalDate.now()
            .format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", locale))
            .replaceFirstChar { it.titlecase(locale) }
        renderDayProgress()
        renderBattery()
        // El calendario se consulta como mucho cada 30 s (o si cambia el día)
        val today = LocalDate.now()
        if (SystemClock.elapsedRealtime() - lastCalendarQuery > CALENDAR_REFRESH_MS || today != lastCalendarDay) {
            renderCalendar()
        }
        renderFavorites()
        renderDock()
    }

    // El botón atrás no debe cerrar el launcher
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() { }

    // Libera iconos si el sistema anda corto de memoria
    @Suppress("DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) {
            iconCache.evictAll()
            labelCache.clear()
            appsSig = null
            dockSig = null
        }
    }

    // ---------------- Tarjeta azul: progreso del día ----------------

    private fun renderDayProgress() {
        val pct = LocalTime.now().toSecondOfDay() * 100 / 86_400
        // Los 3 segmentos se crean una vez y luego solo se recolorean
        if (daySegments.childCount == 0) {
            for (i in 0 until 3) {
                daySegments.addView(View(this), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply {
                    if (i > 0) marginStart = 6.dp
                })
            }
        }
        for (i in 0 until 3) {
            daySegments.getChildAt(i).background = rounded(if (pct > i * 33) Color.WHITE else 0x66FFFFFF, 2)
        }
        dayPct.text = "$pct % del día"
    }

    // ---------------- Batería (se lee al volver a inicio, sin escuchar en segundo plano) ----------------

    /** Tarjeta a todo el ancho: «Batería» a la izquierda, etiqueta y porcentaje a la derecha, barra debajo. */
    private fun buildBatteryTile(container: LinearLayout): StatTile {
        container.background = rounded(Color.WHITE, 16)
        container.setPadding(14.dp, 12.dp, 14.dp, 14.dp)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(TextView(this).apply {
            text = "Batería"
            setTextColor(TEXT)
            textSize = 14f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val pill = TextView(this).apply {
            setTextColor(BLUE)
            textSize = 10f
            maxLines = 1
            background = rounded(BLUE_SOFT, 999)
            setPadding(8.dp, 2.dp, 8.dp, 2.dp)
        }
        val value = TextView(this).apply { setTextColor(TEXT); textSize = 22f }
        row.addView(pill, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = 8.dp })
        row.addView(value)
        container.addView(row)
        val track = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 100f
            background = rounded(TRACK, 3)
        }
        val fill = View(this).apply { background = rounded(BLUE, 3) }
        track.addView(fill, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 0f))
        container.addView(track, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 5.dp).apply {
            topMargin = 8.dp
        })
        return StatTile(value, pill, fill)
    }

    private fun setTile(tile: StatTile, pct: Int, pillText: String?, barColor: Int = BLUE) {
        tile.value.text = "$pct%"
        tile.pill.text = pillText ?: ""
        tile.pill.visibility = if (pillText == null) View.GONE else View.VISIBLE
        tile.fill.background = rounded(barColor, 3)
        tile.fill.layoutParams = (tile.fill.layoutParams as LinearLayout.LayoutParams).apply { weight = pct.toFloat() }
    }

    private fun renderBattery() {
        val bm = getSystemService(BatteryManager::class.java) ?: return
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
        val pill = when {
            bm.isCharging -> "Cargando"
            level <= 15 -> "Baja"
            else -> null
        }
        setTile(battery, level, pill, if (level <= 15 && !bm.isCharging) DANGER else BLUE)
    }

    // ---------------- Calendario ----------------

    private fun hasCalendarPermission() =
        checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    private fun onCalendarTap() {
        if (!hasCalendarPermission()) {
            requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), REQ_CALENDAR)
            return
        }
        val uri = CalendarContract.CONTENT_URI.buildUpon()
            .appendPath("time").appendPath(System.currentTimeMillis().toString()).build()
        launch(Intent(Intent.ACTION_VIEW, uri))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CALENDAR) renderCalendar()
    }

    private fun renderCalendar() {
        val today = LocalDate.now()
        lastCalendarQuery = SystemClock.elapsedRealtime()
        lastCalendarDay = today
        val monday = today.with(DayOfWeek.MONDAY)
        val zone = ZoneId.systemDefault()
        val eventDays = HashSet<LocalDate>()
        var todayCount = 0
        var nextToday: String? = null
        eventsBox.removeAllViews()

        if (hasCalendarPermission()) {
            val from = monday.atStartOfDay(zone).toInstant().toEpochMilli()
            val to = today.plusDays(8).atStartOfDay(zone).toInstant().toEpochMilli()
            val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also {
                ContentUris.appendId(it, from)
                ContentUris.appendId(it, to)
            }.build()
            val projection = arrayOf(
                CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.END,
                CalendarContract.Instances.ALL_DAY
            )
            val now = System.currentTimeMillis()
            var shown = 0
            try {
                contentResolver.query(
                    uri, projection, "${CalendarContract.Instances.VISIBLE}=1", null,
                    "${CalendarContract.Instances.BEGIN} ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val title = c.getString(0)?.takeIf { it.isNotBlank() } ?: "(Sin título)"
                        val begin = c.getLong(1)
                        val end = c.getLong(2)
                        val allDay = c.getInt(3) == 1
                        // Los eventos de día completo se guardan en UTC
                        val day = Instant.ofEpochMilli(begin)
                            .atZone(if (allDay) ZoneOffset.UTC else zone).toLocalDate()
                        eventDays.add(day)
                        if (day == today) {
                            todayCount++
                            if (nextToday == null && end > now) nextToday = if (allDay) "todo el día" else "a las ${hhmm(begin)}"
                        }
                        if (end > now && shown < MAX_EVENTS) {
                            addEventRow(day, begin, end, allDay, title)
                            shown++
                        }
                    }
                }
            } catch (_: Exception) { }
            if (shown == 0) addHint("Sin eventos esta semana")
            heroInfo.text = when (todayCount) {
                0 -> "Día libre, sin eventos"
                1 -> "1 evento" + (nextToday?.let { " · $it" } ?: "")
                else -> "$todayCount eventos" + (nextToday?.let { " · siguiente $it" } ?: "")
            }
        } else {
            addHint("Toca «Ver todo» para mostrar tus eventos")
            heroInfo.text = "Permite el calendario para ver tu día"
        }

        weekStrip.removeAllViews()
        for (i in 0..6) {
            val d = monday.plusDays(i.toLong())
            val isToday = d == today
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, 5.dp, 0, 5.dp)
                if (isToday) background = rounded(BLUE, 999)
            }
            cell.addView(TextView(this).apply {
                text = d.dayOfWeek.getDisplayName(TextStyle.NARROW, Locale.getDefault())
                setTextColor(if (isToday) Color.WHITE else SUB)
                textSize = 11f
                gravity = Gravity.CENTER
            })
            cell.addView(TextView(this).apply {
                text = d.dayOfMonth.toString()
                textSize = 14f
                gravity = Gravity.CENTER
                typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                setTextColor(if (isToday) Color.WHITE else TEXT)
                setPadding(0, 2.dp, 0, 0)
            })
            // Punto si ese día tiene eventos
            cell.addView(View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(
                        when {
                            d !in eventDays -> Color.TRANSPARENT
                            isToday -> Color.WHITE
                            else -> BLUE
                        }
                    )
                }
            }, LinearLayout.LayoutParams(4.dp, 4.dp).apply { topMargin = 3.dp })
            weekStrip.addView(cell, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = 2.dp; marginEnd = 2.dp
            })
        }
    }

    private fun hhmm(millis: Long) =
        Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))

    private fun addEventRow(day: LocalDate, begin: Long, end: Long, allDay: Boolean, title: String) {
        val locale = Locale.getDefault()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 6.dp, 0, 6.dp)
        }
        // Chip de fecha: día y mes
        val chip = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(BLUE_SOFT, 10)
        }
        chip.addView(TextView(this).apply {
            text = day.dayOfMonth.toString()
            setTextColor(BLUE)
            textSize = 14f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            includeFontPadding = false
        })
        chip.addView(TextView(this).apply {
            text = day.month.getDisplayName(TextStyle.SHORT, locale).trimEnd('.').uppercase(locale)
            setTextColor(BLUE)
            textSize = 9f
            includeFontPadding = false
        })
        row.addView(chip, LinearLayout.LayoutParams(38.dp, 38.dp).apply { marginEnd = 10.dp })

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply {
            text = title
            setTextColor(TEXT)
            textSize = 13f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        })
        texts.addView(TextView(this).apply {
            text = if (allDay) "Todo el día" else "${hhmm(begin)} – ${hhmm(end)}"
            setTextColor(SUB)
            textSize = 12f
        })
        row.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        eventsBox.addView(row)
    }

    private fun addHint(msg: String) {
        eventsBox.addView(TextView(this).apply {
            text = msg
            setTextColor(SUB)
            textSize = 13f
            setPadding(0, 8.dp, 0, 6.dp)
        })
    }

    // ---------------- Iconos cuadrados ----------------

    /**
     * Convierte cualquier icono en un cuadrado de esquinas suaves, igual para todas las apps.
     * Los iconos adaptativos se recomponen con sus capas; los antiguos se centran sobre un fondo neutro.
     */
    private fun squareIcon(key: String, sizeDp: Int, load: () -> Drawable?): Drawable? {
        val cacheKey = "$key@$sizeDp"
        // Primero la caché: así no se vuelve a pedir ni decodificar el icono al volver a inicio
        iconCache.get(cacheKey)?.let { return it }
        val src = load() ?: return null
        val s = sizeDp.dp
        val content = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(content)
        if (src is AdaptiveIconDrawable) {
            // Las capas miden 108dp con una zona útil de 72dp: se amplían 1,5x y se centran
            val o = s / 4
            src.background?.let { it.setBounds(-o, -o, s + o, s + o); it.draw(c) }
            src.foreground?.let { it.setBounds(-o, -o, s + o, s + o); it.draw(c) }
        } else {
            c.drawColor(TRACK)
            val inset = (s * 0.14f).toInt()
            src.setBounds(inset, inset, s - inset, s - inset)
            src.draw(c)
        }
        // Recorte con antialiasing (bordes suaves, sin dientes de sierra)
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        Canvas(out).apply {
            val r = s * 0.24f
            drawRoundRect(0f, 0f, s.toFloat(), s.toFloat(), r, r, paint)
            paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
            drawBitmap(content, 0f, 0f, paint)
        }
        content.recycle()
        return BitmapDrawable(resources, out).also { iconCache.put(cacheKey, it) }
    }

    /** Nombre de una app, cacheado para no consultarlo en cada vuelta a inicio. */
    @Suppress("DEPRECATION")
    private fun labelOf(cn: ComponentName): String = labelCache.getOrPut(cn.flattenToString()) {
        try { packageManager.getActivityInfo(cn, 0).loadLabel(packageManager).toString() } catch (_: Exception) { cn.packageName }
    }

    // ---------------- Categorías ----------------

    private fun catKey(cat: Int) = "cat_$cat"

    /** Apps de una categoría, en el orden en que las añadiste. */
    private fun loadFavorites(cat: Int = selectedCat): MutableList<ComponentName> =
        (prefs.getString(catKey(cat), "") ?: "").split('|')
            .filter { it.isNotBlank() }
            .mapNotNull { ComponentName.unflattenFromString(it) }
            .toMutableList()

    private fun saveFavorites(list: List<ComponentName>, cat: Int = selectedCat) {
        prefs.edit().putString(catKey(cat), list.joinToString("|") { it.flattenToString() }).apply()
    }

    /** Las favoritas de la versión anterior pasan a «Otros» para no perderlas. */
    private fun migrateOldFavorites() {
        val old = prefs.getString(KEY_FAVS, null) ?: return
        val otros = CATEGORIES.lastIndex
        if (prefs.getString(catKey(otros), "").isNullOrEmpty()) prefs.edit().putString(catKey(otros), old).apply()
        prefs.edit().remove(KEY_FAVS).apply()
    }

    private fun renderCategories() {
        categoryTabs.removeAllViews()
        val sel = selectedCat
        CATEGORIES.forEachIndexed { i, name ->
            val active = i == sel
            categoryTabs.addView(TextView(this).apply {
                text = name
                textSize = 12f
                setTextColor(if (active) Color.WHITE else 0xFF4A5367.toInt())
                background = rounded(if (active) BLUE else TAB_BG, 999)
                setPadding(14.dp, 6.dp, 14.dp, 6.dp)
                setOnClickListener {
                    selectedCat = i
                    renderCategories()
                }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { if (i > 0) marginStart = 6.dp })
        }
        renderFavorites()
    }

    @Suppress("DEPRECATION")
    private fun isInstalled(cn: ComponentName) = try {
        packageManager.getActivityInfo(cn, 0); true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    private fun renderFavorites() {
        val cat = selectedCat
        // Si la categoría y su lista no han cambiado, las vistas actuales siguen valiendo
        val sig = "$cat|" + (prefs.getString(catKey(cat), "") ?: "")
        if (sig == appsSig) return
        appsSig = sig
        appsBox.removeAllViews()
        val favs = loadFavorites(cat).filter { isInstalled(it) }
        if (favs.isEmpty()) {
            appsBox.addView(TextView(this).apply {
                text = "Toca «Editar» para añadir apps a ${CATEGORIES[selectedCat]}"
                setTextColor(SUB)
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(0, 10.dp, 0, 14.dp)
            })
            return
        }
        favs.chunked(COLUMNS).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEach { cn ->
                row.addView(appCell(cn), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            repeat(COLUMNS - rowItems.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            appsBox.addView(row)
        }
    }

    private fun appCell(cn: ComponentName): View {
        val pm = packageManager
        val label = labelOf(cn)
        // El icono solo se carga del sistema si no está ya en caché
        val icon = squareIcon(cn.flattenToString(), 46) {
            try { pm.getActivityIcon(cn) } catch (_: Exception) { pm.defaultActivityIcon }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 4.dp, 0, 8.dp)
            addView(ImageView(context).apply { setImageDrawable(icon) }, LinearLayout.LayoutParams(46.dp, 46.dp))
            addView(TextView(context).apply {
                text = label
                setTextColor(0xFF4A5367.toInt())
                textSize = 11f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setPadding(4.dp, 4.dp, 4.dp, 0)
            })
            setOnClickListener { launchApp(cn) }
            setOnLongClickListener { appMenu(cn, label); true }
        }
    }

    private fun appMenu(cn: ComponentName, label: String) {
        val cat = selectedCat
        AlertDialog.Builder(this)
            .setTitle(label)
            .setItems(arrayOf("Quitar de ${CATEGORIES[cat]}", "Mover a otra categoría", "Información de la app")) { _, which ->
                when (which) {
                    0 -> {
                        saveFavorites(loadFavorites(cat).filter { it != cn }, cat)
                        renderFavorites()
                    }
                    1 -> moveToCategory(cn, cat)
                    else -> launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${cn.packageName}")))
                }
            }
            .show()
    }

    private fun moveToCategory(cn: ComponentName, from: Int) {
        val targets = CATEGORIES.indices.filter { it != from }
        AlertDialog.Builder(this)
            .setTitle("Mover a…")
            .setItems(targets.map { CATEGORIES[it] }.toTypedArray()) { _, i ->
                val to = targets[i]
                val dest = loadFavorites(to)
                if (dest.size >= MAX_FAVS) {
                    Toast.makeText(this, "${CATEGORIES[to]} ya tiene $MAX_FAVS apps", Toast.LENGTH_SHORT).show()
                    return@setItems
                }
                if (cn !in dest) saveFavorites(dest + cn, to)
                saveFavorites(loadFavorites(from).filter { it != cn }, from)
                renderFavorites()
            }
            .show()
    }

    // ---------------- Dock ----------------

    private fun dockSpec(slot: Int) = prefs.getString("dock$slot", null) ?: DOCK_DEFAULTS[slot].first

    @Suppress("DEPRECATION")
    private fun resolveDock(slot: Int): DockTarget {
        val pm = packageManager
        val spec = dockSpec(slot)
        val defaultLabel = DOCK_DEFAULTS[slot].second
        return when {
            spec == "dial" -> intentTarget(Intent(Intent.ACTION_DIAL), defaultLabel)
            spec == "camera" -> intentTarget(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), defaultLabel)
            spec.startsWith("pkg:") -> {
                val pkg = spec.removePrefix("pkg:")
                val i = pm.getLaunchIntentForPackage(pkg)
                DockTarget(i, i?.let { { runCatching { pm.getApplicationIcon(pkg) }.getOrNull() } }, defaultLabel)
            }
            else -> {
                val cn = ComponentName.unflattenFromString(spec.removePrefix("cmp:"))
                if (cn == null || !isInstalled(cn)) DockTarget(null, null, defaultLabel)
                else DockTarget(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(cn),
                    { runCatching { pm.getActivityIcon(cn) }.getOrNull() },
                    labelOf(cn)
                )
            }
        }
    }

    /** Para acciones del sistema (marcador, cámara) usa la app predeterminada, o la primera disponible. */
    private fun intentTarget(intent: Intent, label: String): DockTarget {
        val pm = packageManager
        val def = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        val info = if (def == null || def.activityInfo.name.endsWith("ResolverActivity"))
            pm.queryIntentActivities(intent, 0).firstOrNull() else def
        return DockTarget(info?.let { intent }, info?.let { ri -> { ri.loadIcon(pm) } }, label)
    }

    private fun renderDock() {
        // Si la configuración del dock no ha cambiado, no se vuelve a resolver ni a dibujar
        val sig = DOCK_DEFAULTS.indices.joinToString("|") { dockSpec(it) }
        if (sig == dockSig) return
        dockSig = sig
        dock.removeAllViews()
        for (slot in DOCK_DEFAULTS.indices) {
            val t = resolveDock(slot)
            val icon = t.loadIcon?.let { squareIcon("dock$slot:${dockSpec(slot)}", 50, it) }
            val view = ImageView(this).apply {
                contentDescription = t.label
                if (icon != null) {
                    setImageDrawable(icon)
                } else {
                    // App no instalada: cuadrado vacío atenuado
                    setImageDrawable(rounded(TRACK, 12))
                    alpha = 0.6f
                }
                setOnClickListener {
                    if (t.intent != null) launch(Intent(t.intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    else Toast.makeText(this@MainActivity, "${t.label} no está instalada", Toast.LENGTH_SHORT).show()
                }
                setOnLongClickListener { changeDockSlot(slot); true }
            }
            val cell = LinearLayout(this).apply { gravity = Gravity.CENTER }
            cell.addView(view, LinearLayout.LayoutParams(50.dp, 50.dp))
            dock.addView(cell, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
    }

    /** Mantener pulsado un icono del dock permite cambiarlo por otra app. */
    private fun changeDockSlot(slot: Int) {
        val apps = queryApps()
        val labels = arrayOf("Restablecer (${DOCK_DEFAULTS[slot].second})") + apps.map { it.label }
        AlertDialog.Builder(this)
            .setTitle("Cambiar icono del dock")
            .setItems(labels) { _, i ->
                val edit = prefs.edit()
                if (i == 0) edit.remove("dock$slot")
                else edit.putString("dock$slot", "cmp:" + apps[i - 1].component.flattenToString())
                edit.apply()
                renderDock()
            }
            .show()
    }

    // ---------------- Todas las apps ----------------

    /** Solo etiquetas (sin iconos) para gastar el mínimo de memoria. */
    private fun queryApps(): List<AppEntry> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val cn = ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                AppEntry(labelCache.getOrPut(cn.flattenToString()) { it.loadLabel(pm).toString() }, cn)
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun showAllApps() {
        val apps = queryApps()
        AlertDialog.Builder(this)
            .setTitle("Todas las apps")
            .setItems(apps.map { it.label }.toTypedArray()) { _, i -> launchApp(apps[i].component) }
            .show()
    }

    private fun pickFavorites() {
        val cat = selectedCat
        val apps = queryApps()
        val current = loadFavorites(cat)
        val checked = BooleanArray(apps.size) { apps[it].component in current }
        AlertDialog.Builder(this)
            .setTitle("${CATEGORIES[cat]} (máx. $MAX_FAVS)")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, isChecked ->
                checked[i] = isChecked
            }
            .setPositiveButton("Guardar") { _, _ ->
                val selected = apps.indices.filter { checked[it] }.map { apps[it].component }
                // Mantiene el orden previo y añade las nuevas al final
                val ordered = current.filter { it in selected } + selected.filter { it !in current }
                if (ordered.size > MAX_FAVS) {
                    Toast.makeText(this, "Solo se guardan las primeras $MAX_FAVS", Toast.LENGTH_SHORT).show()
                }
                saveFavorites(ordered.take(MAX_FAVS), cat)
                renderFavorites()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------------- Utilidades ----------------

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = radiusDp.dp.toFloat()
        setColor(color)
    }

    private fun outlinePill() = GradientDrawable().apply {
        cornerRadius = 999.dp.toFloat()
        setColor(Color.WHITE)
        setStroke(1.dp, BORDER)
    }

    private fun launchApp(cn: ComponentName) = launch(
        Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(cn)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    )

    private fun launch(intent: Intent) {
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "No se pudo abrir", Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        private const val KEY_FAVS = "favs" // solo para migrar la versión anterior
        private const val KEY_SEL_CAT = "cat_sel"

        /** Categorías de apps; «Otros» siempre la última */
        private val CATEGORIES = listOf("Redes", "IA", "Personal", "Gym", "Deportes", "Otros")
        private const val REQ_CALENDAR = 1
        private const val MAX_FAVS = 12
        private const val MAX_EVENTS = 3
        private const val COLUMNS = 4
        private const val ICON_CACHE_BYTES = 3 * 1024 * 1024 // 3 MB como máximo para iconos
        private const val CALENDAR_REFRESH_MS = 30_000L

        // Paleta: panel claro con acento azul
        private const val BLUE = 0xFF2F6BEA.toInt()
        private const val BLUE_SOFT = 0xFFE6F1FB.toInt()
        private const val TEXT = 0xFF1B2232.toInt()
        private const val SUB = 0xFF7A8396.toInt()
        private const val TRACK = 0xFFE6ECF5.toInt()
        private const val TAB_BG = 0xFFEEF1F6.toInt()
        private const val BORDER = 0xFFD6E0F0.toInt()
        private const val DANGER = 0xFFE24B4A.toInt()

        /** Dock por defecto: Teléfono, WhatsApp, Brave y Cámara */
        private val DOCK_DEFAULTS = listOf(
            "dial" to "Teléfono",
            "pkg:com.whatsapp" to "WhatsApp",
            "pkg:com.brave.browser" to "Brave",
            "camera" to "Cámara"
        )
    }
}
